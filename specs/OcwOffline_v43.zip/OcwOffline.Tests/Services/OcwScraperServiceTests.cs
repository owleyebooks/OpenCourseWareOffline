using OcwOffline.Models;
using OcwOffline.Services;

namespace OcwOffline.Tests.Services;

public class OcwScraperServiceTests
{
    [Fact]
    public void MakeAbsolute_AlreadyHttps_ReturnsUnchanged()
    {
        var result = OcwScraperService.MakeAbsolute("https://ocw.mit.edu/foo/bar.pdf");

        Assert.Equal("https://ocw.mit.edu/foo/bar.pdf", result);
    }

    [Fact]
    public void MakeAbsolute_AlreadyHttp_ReturnsUnchanged()
    {
        var result = OcwScraperService.MakeAbsolute("http://example.com/foo.pdf");

        Assert.Equal("http://example.com/foo.pdf", result);
    }

    [Fact]
    public void MakeAbsolute_RootRelative_PrependsHost()
    {
        var result = OcwScraperService.MakeAbsolute("/courses/foo/bar.pdf");

        Assert.Equal("https://ocw.mit.edu/courses/foo/bar.pdf", result);
    }

    [Fact]
    public void MakeAbsolute_RelativeWithoutLeadingSlash_PrependsHostAndSlash()
    {
        var result = OcwScraperService.MakeAbsolute("courses/foo/bar.pdf");

        Assert.Equal("https://ocw.mit.edu/courses/foo/bar.pdf", result);
    }

    [Theory]
    [InlineData("10", "KB", 10L * 1024)]
    [InlineData("10", "kB", 10L * 1024)]
    [InlineData("1.5", "MB", (long)(1.5 * 1024 * 1024))]
    [InlineData("2", "GB", 2L * 1024 * 1024 * 1024)]
    public void ParseSize_KnownUnits_ConvertsToBytes(string numeric, string unit, long expected)
    {
        var result = OcwScraperService.ParseSize(numeric, unit);

        Assert.Equal(expected, result);
    }

    [Fact]
    public void ParseSize_UnrecognizedUnit_TreatsAsBytes()
    {
        var result = OcwScraperService.ParseSize("42", "TB");

        Assert.Equal(42L, result);
    }

    [Fact]
    public void ParseSize_NonNumericValue_ReturnsZero()
    {
        var result = OcwScraperService.ParseSize("not-a-number", "MB");

        Assert.Equal(0L, result);
    }

    [Fact]
    public void ClassifyArtifact_ZipLabel_ReturnsZip()
    {
        var result = OcwScraperService.ClassifyArtifact("https://ocw.mit.edu/x", "zip");

        Assert.Equal(ArtifactFileType.Zip, result);
    }

    [Fact]
    public void ClassifyArtifact_ZipExtensionRegardlessOfLabel_ReturnsZip()
    {
        var result = OcwScraperService.ClassifyArtifact("https://ocw.mit.edu/x.ZIP", "file");

        Assert.Equal(ArtifactFileType.Zip, result);
    }

    [Fact]
    public void ClassifyArtifact_PdfLabel_ReturnsPdf()
    {
        var result = OcwScraperService.ClassifyArtifact("https://ocw.mit.edu/x", "pdf");

        Assert.Equal(ArtifactFileType.Pdf, result);
    }

    [Fact]
    public void ClassifyArtifact_HtmlExtension_ReturnsHtml()
    {
        var result = OcwScraperService.ClassifyArtifact("https://ocw.mit.edu/x.html", "file");

        Assert.Equal(ArtifactFileType.Html, result);
    }

    [Fact]
    public void ClassifyArtifact_HtmExtension_ReturnsHtml()
    {
        var result = OcwScraperService.ClassifyArtifact("https://ocw.mit.edu/x.htm", "file");

        Assert.Equal(ArtifactFileType.Html, result);
    }

    [Fact]
    public void ClassifyArtifact_NoMatchingLabelOrExtension_ReturnsOther()
    {
        var result = OcwScraperService.ClassifyArtifact("https://ocw.mit.edu/x.docx", "file");

        Assert.Equal(ArtifactFileType.Other, result);
    }
}
